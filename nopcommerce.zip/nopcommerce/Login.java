package nopcommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login
{
	public void URL(WebDriver  driver)
	{
			//URL
		 driver.get("https://demo.nopcommerce.com/");		
	}
	public void Login(WebDriver  driver)
	{
			
		 driver.findElement(By.xpath("//a[@class='ico-login']")).click();		
	}
	public void Email(WebDriver  driver)
	{
			
		 driver.findElement(By.xpath("//input[@id='Email']")).click();		
	}
	public void Password(WebDriver  driver)
	{
			
		 driver.findElement(By.xpath("//input[@id='Password']")).click();		
	}
	public void Remember(WebDriver  driver)
	{
	 driver.findElement(By.xpath("//input[@id='RememberMe']")).click();		
	}
	public void login(WebDriver  driver)
	{
	driver.findElement(By.xpath("//button[normalize-space()='Log in']")).click();
	}
}
