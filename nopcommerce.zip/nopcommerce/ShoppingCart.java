package nopcommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ShoppingCart
{
	public void URL(WebDriver  driver)
	{
			//URL
		 driver.get("https://demo.nopcommerce.com/");		
	}
	public void Shopping(WebDriver  driver)
	{			
		driver.findElement(By.xpath("//span[@class='cart-label']")).click();		 
	}
	public void Quality(WebDriver  driver)
	{			
		driver.findElement(By.xpath("//input[@id='itemquantity11230']")).sendKeys("4");		 
	}
	
	public void Update(WebDriver  driver)
	{			
		driver.findElement(By.xpath("//button[@id='updatecart']")).click();		 
	}
	public void Cancel(WebDriver  driver)
	{		
		driver.findElement(By.xpath("//td[@class='remove-from-cart']")).click();		 
	}
	public void Logout(WebDriver  driver)
	{			
		driver.findElement(By.xpath("//a[@class='ico-logout']")).click();		 
	}
	

}
