package nopcommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Registration 
{
	public void URL(WebDriver  driver)
	{
			//URL
		 driver.get("https://demo.nopcommerce.com/");		
	}
		public void Register(WebDriver driver)
		{
				driver.findElement(By.xpath("//a[@class='ico-register']")).click();
		}
		public void Gender(WebDriver driver)
		{
				driver.findElement(By.xpath("//input[@id='gender-male']")).click();
		}
		public void FirstName(WebDriver driver)
		{
				driver.findElement(By.xpath("//input[@id='FirstName']")).sendKeys("Arjun");
		}
		public void LastName(WebDriver driver)
		{
				driver.findElement(By.xpath("//input[@id='LastName']")).sendKeys("Allu");
		}
		public void Date(WebDriver driver)
		{
				driver.findElement(By.xpath("//select[@name='DateOfBirthDay']")).sendKeys("23");
		}
		public void Month(WebDriver driver)
		{
				driver.findElement(By.xpath("//select[@name='DateOfBirthMonth']")).sendKeys("May");
		}
		public void Year(WebDriver driver)
		{
				driver.findElement(By.xpath("//select[@name='DateOfBirthYear']")).sendKeys("2000");
		}
		public void Email(WebDriver driver)
		{
				driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("Arjun23@gmail.com");
		}
		public void Password(WebDriver driver)
		{
				driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Arjun@23");
		}
		public void Confirmpassword(WebDriver driver)
		{
				driver.findElement(By.xpath("//input[@id='ConfirmPassword']")).sendKeys("Arjun@23");
		}
		public void register(WebDriver driver)
		{
				driver.findElement(By.xpath("//button[@id='register-button']")).click();
		}
		public void home(WebDriver driver)
		{
			driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']")).click();
		}
	
	
}
