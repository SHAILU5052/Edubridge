package nopcommerce;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;


public class MainClass {
	WebDriver driver;
  @BeforeTest
  public void beforeTest() throws Exception
  {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\shailaja\\OneDrive\\Documents\\Automation\\Browser extantion\\chromedriver.exe");
		 driver=new ChromeDriver(); 
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		
		
  }
  @Test
  public void Registration() throws InterruptedException 
  {
	  Registration r=new Registration();
	  r.URL(driver);
	  Thread.sleep(2000);
	  r.Register(driver);
	  Thread.sleep(2000);
	  r.Gender(driver);
	  Thread.sleep(2000);
	  r.FirstName(driver);
	  Thread.sleep(2000);
	  r.LastName(driver);
	  Thread.sleep(2000);
	  r.Date(driver);
	  Thread.sleep(2000);
	  r.Month(driver);
	  Thread.sleep(2000);
	  r.Year(driver);
	  Thread.sleep(2000);
	  r.Email(driver);
	  Thread.sleep(2000);
	  r.Password(driver);
	  Thread.sleep(2000);
	  r.Confirmpassword(driver);
	  Thread.sleep(2000);
	  r.home(driver);
	  Login l=new Login();
	  l.URL(driver);
	  l.Login(driver);
	  l.Email(driver);
	  l.Password(driver);
	  l.Remember(driver);
	  l.login(driver);
	  
	  AddToCart a=new AddToCart();
	  a.URL(driver);
	  a.Computer(driver);
	  a.Notebooks(driver);
	  a.CPU(driver);
	  a.Memory(driver);
	  a.Order(driver);
	  a.Count(driver);
	  a.Wishlist(driver);
	  
	  
	  ShoppingCart  s=new ShoppingCart();
	  s.URL(driver);
	  s.Shopping(driver);
	  s.Quality(driver);
	  s.Update(driver);
	  s.Cancel(driver);
	  s.Logout(driver);
	  
	  
	  
  }
  
  @AfterTest
  public void afterTest() {
	  
	  driver.close();
	  
  }

}
