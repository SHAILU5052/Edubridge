package nopcommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AddToCart
{

	public void URL(WebDriver  driver)
	{
			//URL
		 driver.get("https://demo.nopcommerce.com/");		
	}
	public void Computer(WebDriver  driver)
	{
		driver.findElement(By.xpath("//ul[@class='top-menu notmobile']//a[normalize-space()='Computers']")).click();
		 
	}
	public void Notebooks(WebDriver driver) 
	{
		driver.findElement(By.xpath("//img[@title='Show products in category Notebooks']")).click();	
		
		
	}
	public void CPU(WebDriver  driver)
	{
			//URL
		driver.findElement(By.xpath("//input[@id='attribute-option-7']")).click();		 
	}
	public void Memory(WebDriver  driver)
	{
			//URL
		driver.findElement(By.xpath("//input[@id='attribute-option-10']")).click();		 
	}
	public void Order(WebDriver  driver)
	{
			//URL
		driver.findElement(By.xpath("//div[@class='item-grid']//div[1]//div[1]//div[2]//div[3]//div[2]//button[1]")).click();		 
	}
	public void Count(WebDriver  driver)
	{
			//URL
		driver.findElement(By.xpath("//input[@id='product_enteredQuantity_4']")).sendKeys("2");		 
	}
	public void Wishlist(WebDriver  driver)
	{
			//URL
		driver.findElement(By.xpath("//button[@id='add-to-wishlist-button-4']")).click();		 
	}
	
	
	
}
