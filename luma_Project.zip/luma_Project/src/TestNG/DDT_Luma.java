package TestNG;

import org.testng.annotations.Test;

import KDT_framework.OperationalClass_L;

import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class DDT_Luma {
	WebDriver driver;
	
	  @BeforeTest
	  public void beforeTest() 
	  {
		  System.setProperty("webdriver.chrome.driver", " \"C:\\Users\\shailaja\\OneDrive\\Documents\\Automation\\Browser extantion\\chromedriver.exe\"");
		   driver= new ChromeDriver();
		   driver.manage().window().maximize();
		   driver.manage().deleteAllCookies();
	  }
  @Test(dataProvider = "dp")
  public void f(String email, String password) throws Exception 
  {
	  OperationalClass_L  l= new OperationalClass_L ();
	  l.url(driver);
      l.maximize(driver);
      l.cookies(driver);
      Thread.sleep(2000);
      l.email(driver, email);
      l.password(driver, password);
      Thread.sleep(2000);
      l.signinbutton(driver);
      Thread.sleep(2000);
      l.welcomeAdmin(driver);
      Thread.sleep(2000);
      l.signout(driver);
 }
  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "Shailajaarige27@gmail.com", "Shailu@123" },
      new Object[] { "Key25@gmail.com", "key@123" },
      new Object[] { "Mon21@gmail.com.com", "Mon@123" },
      new Object[] { "Vaishu18@gmail.com", "Vaishu@123" },
      new Object[] { "Chandu@gmail.com", "Chandu@5" },
      new Object[] { "Satu@gmail.com.com", "Satu13" },
    };
  }
  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
