package TestNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Luma_Parallel_Testing 
{
	WebDriver driver;
	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
	public void email(WebDriver driver, String email)
	 {
		driver.findElement(By.partialLinkText("Sign")).click();  
		
		 driver.findElement(By.id("email")).sendKeys(email);
	 }
	 public void password(WebDriver driver, String password)
	 {
		 driver.findElement(By.id("pass")).sendKeys(password);
	 }
	 public void signinbutton(WebDriver driver)
	 {
		 driver.findElement(By.id("send2")).click();
	 }
	 public void welcomeAdmin(WebDriver driver)
	 {
		 driver.findElement(By.xpath("//span[@aria-expanded='false']")).click();
	 }
	 public void signout(WebDriver driver)
	 {
		 driver.findElement(By.partialLinkText("Sign")).click();
	 }
	@BeforeTest
	  public void beforeTest() 
	 {
		 System.setProperty("webdriver.chrome.driver", "\"C:\\Users\\shailaja\\OneDrive\\Documents\\Automation\\Browser extantion\\chromedriver.exe\"");
		   driver= new ChromeDriver();
		   driver.manage().window().maximize();
		   driver.manage().deleteAllCookies();
	  }		
	@Test(description= "Parallel Testing")
	  public void Luma() throws InterruptedException 
	  {
		Luma_Parallel_Testing l= new Luma_Parallel_Testing();
		l.url(driver);
        Thread.sleep(2000);
        l.email(driver, "Shailajaarige27@gmail.com");
        Thread.sleep(2000);
        l.password(driver, "Shailu@123");
        Thread.sleep(2000);
        l.signinbutton(driver);
        Thread.sleep(2000);
        l.welcomeAdmin(driver);
        Thread.sleep(2000);
        l.signout(driver);
        Thread.sleep(2000);
	  }
@AfterTest
public void afterTest() 
{
	  driver.close();
}

}
