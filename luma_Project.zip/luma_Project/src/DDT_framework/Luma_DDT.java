package DDT_framework;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Luma_DDT 
{
	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
   public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
   public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
	public void email(WebDriver driver, String email)
	 {
		driver.findElement(By.partialLinkText("Sign")).click();  
		
		 driver.findElement(By.id("email")).sendKeys(email);
	 }
	 public void password(WebDriver driver, String password)
	 {
		 driver.findElement(By.id("pass")).sendKeys(password);
	 }
	 public void signinbutton(WebDriver driver)
	 {
		 driver.findElement(By.id("send2")).click();
	 }
	 public void welcomeAdmin(WebDriver driver)
	 {
		 driver.findElement(By.xpath("//span[@aria-expanded='false']")).click();
	 }
	 public void signout(WebDriver driver)
	 {
		 driver.findElement(By.partialLinkText("Sign")).click();
	 }
	public static void main(String[] args) throws Exception
	{
		//excelsheet>>datafiles
				FileInputStream file= new FileInputStream("C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\POI\\Luma_POI.xlsx");
		        XSSFWorkbook w= new XSSFWorkbook(file);
		        
		        XSSFSheet s= w.getSheet("Luma_DDT");
		        
		        int rowSize = s.getLastRowNum();
		        System.out.println("No of Credential: "+ rowSize);
		        
		        
		       System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\chromedriver.exe");
		       WebDriver driver= new ChromeDriver();
		        
		       Luma_DDT l= new Luma_DDT();
		       
		       //Loop
		       for(int i=1;i<=rowSize;i++)
		       {
		    	   //store username and password in the form of variable
		       String email= s.getRow(i).getCell(0).getStringCellValue();
		       String password= s.getRow(i).getCell(1).getStringCellValue();
		       
		       System.out.println(email+"/t/t"+password);
		       
		       try //handle runtime error/exception bcz of invalid credential
		       {
		       l.url(driver);
		       l.maximize(driver);
		       l.cookies(driver);
		       Thread.sleep(2000);
		       l.email(driver, email);
		       l.password(driver, password);
		       Thread.sleep(2000);
		       l.signinbutton(driver);
		       Thread.sleep(2000);
		       l.welcomeAdmin(driver);
		       Thread.sleep(2000);
		       l.signout(driver);
		       
		        //update Test Result
		       System.out.println("Valid Credential");
		       System.out.println("");
		       s.getRow(i).createCell(2).setCellValue("Valid Credential"); 
		       }
		       catch(Exception e)
		       {
		    	 //update Test Result
		           System.out.println("InValid Credential");
		           System.out.println("");
		           s.getRow(i).createCell(2).setCellValue("InValid Credential");
		       }
		       
			}
		     //update Test Result
		       FileOutputStream out= new FileOutputStream("C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\POI\\Luma_POI.xlsx");
				w.write(out);
			   driver.close();

	}

}
