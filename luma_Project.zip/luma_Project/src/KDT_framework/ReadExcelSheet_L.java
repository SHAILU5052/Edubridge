package KDT_framework;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;


public class ReadExcelSheet_L
{

	public  void readExcel(WebDriver driver) throws Exception
	{
		//ExcelSheet
		FileInputStream file=new FileInputStream("C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\POI\\Luma_POI.xlsx");
		
		XSSFWorkbook w= new XSSFWorkbook(file);
		
		XSSFSheet s= w.getSheet("Luma_DDT");
		
		int rowSize= s.getLastRowNum();
		System.out.println("No of Keywords: "+ rowSize );
		
		OperationalClass_L  l= new OperationalClass_L ();
		   for(int i=1; i<rowSize; i++)
		   {
			 String Key= s.getRow(i).getCell(0).getStringCellValue();
			 System.out.println("Key");
			 
			    if(Key.equals("OpenApplication"))
			    {
			    	l.url(driver);
			    	Thread.sleep(2000);
			    }
			    else if (Key.equals("EnterEmail"))
			    {
			    	l.email(driver, "kumaripuja2359@gmail.com");
			    }
			    else if(Key.equals("EnterPassword"))
			    {
			    	l.password(driver, "Family@143");
			    }
			    else if(Key.equals("ClickOnSigninButton"))
			    {
			    	l.signinbutton(driver);
			    	Thread.sleep(2000);
			    }
			    else if(Key.equals("ClickOnWelcomeAdminButton"))
			    {
			    	l.welcomeAdmin(driver);
			    }
			    else if(Key.equals("ClickOnSignoutButton"))
			    {
			    	l.signout(driver);
			    	Thread.sleep(2000);
			    }		    
			    else if(Key.equals("CloseBrowser"))
			    {
			    	driver.close();
			    }	
		 }
	}
}
