package KDT_framework;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import KDT_framework.ReadExcelSheet_L;

public class MainClass_l 
{
	
		public static void main(String[] args) throws InterruptedException
		{
			System.setProperty("webdriver.edge.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\msedgedriver.exe");
	        WebDriver driver= new EdgeDriver();
	        Thread.sleep(2000);
	        ReadExcelSheet_L r= new ReadExcelSheet_L();
	        
		}
}
