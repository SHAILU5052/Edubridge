package mainmodule;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Luma_Registration
		{
	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
public void newuser(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Create an")).click();
		driver.findElement(By.id("firstname")).sendKeys("Shailaja");
		//Thread.sleep(2000);
		driver.findElement(By.id("lastname")).sendKeys("Arige");
		//Thread.sleep(2000);
		driver.findElement(By.id("email_address")).sendKeys("shailajaarige27@gmail.com");
		//Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Admin@123");
		//Thread.sleep(2000);
		driver.findElement(By.id("password-confirmation")).sendKeys("Admin@123");
	//	Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Create an")).click();
	}
			public static void main(String[] args)  throws InterruptedException
			{
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\shailaja\\OneDrive\\Documents\\Automation\\Browser extantion\\chromedriver.exe");
				WebDriver driver =new ChromeDriver();
			
				Luma_Registration r= new  Luma_Registration();
			
				r.url(driver);
				r.maximize(driver);
				r.cookies(driver);
				Thread.sleep(2000);
				r.newuser(driver);
				Thread.sleep(2000);
			
				driver.close();
				
			}
			
			

}
