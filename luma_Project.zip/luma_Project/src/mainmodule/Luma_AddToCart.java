package mainmodule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Luma_AddToCart {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\shailaja\\OneDrive\\Documents\\Automation\\Browser extantion\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://magento.softwaretestingboard.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class='action more button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='product-item-link'][normalize-space()='Echo Fit Compression Short']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@id='option-label-size-143-item-171']")).click();		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@id='option-label-color-93-item-50']")).click();	
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='qty']")).click();	
		driver.findElement(By.xpath("//input[@id='qty']")).clear();
		driver.findElement(By.xpath("//input[@id='qty']")).sendKeys("3");	
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[normalize-space()='Add to Cart']")).click();	
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//a[@class='actionshowcart']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[normalize-space()='View and Edit Cart']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='cart-433895-qty']")).click();
		Thread.sleep(2000);
		//changing product
		driver.findElement(By.xpath("//a[@title='Edit item parameters']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='qty']")).click();
		Thread.sleep(2000);
		//updating product
		driver.findElement(By.xpath("//button[@id='product-updatecart-button']")).click();
		Thread.sleep(2000);
		//checkout
		driver.findElement(By.xpath("//span[normalize-space()='Proceed to Checkout']")).click();
		Thread.sleep(2000);

        
        driver.close();
		
		
		

	}

}
