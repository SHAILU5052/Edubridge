package mainmodule;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Luma_WishList
{
	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
public void newuser(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Create an")).click();
		driver.findElement(By.id("firstname")).sendKeys("Shailaja");
		//Thread.sleep(2000);
		driver.findElement(By.id("lastname")).sendKeys("Arige");
		//Thread.sleep(2000);
		driver.findElement(By.id("email_address")).sendKeys("Shailajaarige27@gmail.com");
		//Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Shailu@123");
		//Thread.sleep(2000);
		driver.findElement(By.id("password-confirmation")).sendKeys("Shailu@123");
	//	Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Create an")).click();
	}
public void signin(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Sign")).click();  
		driver.findElement(By.id("email")).sendKeys("Shailajaarige27@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("pass")).sendKeys("Shailu@123");
		Thread.sleep(2000);
		driver.findElement(By.id("send2")).click();
		driver.findElement(By.xpath("//a[@aria-label='store logo']//img")).click();
	}
	public void wishlists(WebDriver driver) throws InterruptedException
	{
		String searchhere= JOptionPane.showInputDialog("Search Here");
		driver.findElement(By.id("search")).sendKeys(searchhere);
		driver.findElement(By.xpath("//button[@aria-label='Search']")).click();	
		//driver.findElement(By.partialLinkText("tops for")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("option-label-size-143-item-168")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("option-label-color-93-item-60")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//main[@id='maincontent']//div[4]//div[1]//div[2]//a[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@aria-expanded='false']")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("My Wish")).click();
	}
	public void welcomePujaKumari(WebDriver driver)
	 {
		 driver.findElement(By.xpath("//span[@aria-expanded='false']")).click();
	 }
	 public void signout(WebDriver driver)
	 {
		 driver.findElement(By.partialLinkText("Sign")).click();
	 }
	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\shailaja\\\\OneDrive\\\\Documents\\\\Automation\\\\Browser extantion\\\\chromedriver.exe");
        WebDriver driver =new EdgeDriver();
        
        Luma_WishList l= new  Luma_WishList();
        
        l.url(driver);
        l.maximize(driver);
        l.cookies(driver);
        Thread.sleep(2000);
        l.newuser(driver);
        Thread.sleep(2000);
        l.signin(driver);
       // l.searchhere(driver, "Tops" );
    	Thread.sleep(2000);
    	l.wishlists(driver);
    	Thread.sleep(2000);
      l.welcomePujaKumari(driver);
      Thread.sleep(2000);
      l.signout(driver);
      driver.close();

	}
}
