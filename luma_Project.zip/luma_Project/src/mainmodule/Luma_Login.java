package mainmodule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Luma_Login
{	
		public void url(WebDriver driver)
		{
	       driver.get("https://magento.softwaretestingboard.com");
		}
	public void maximize(WebDriver driver)
	    {
		  driver.manage().window().maximize();
	    }
	public void cookies(WebDriver driver)
		{
			driver.manage().deleteAllCookies();
		}


			public void signin(WebDriver driver)
			{
			driver.findElement(By.xpath("//div[@class='panel header']//a[contains(text(),'Sign In')]")).click();  
			}	
			public void email(WebDriver driver, String usn)
			{
			driver.findElement(By.id("email")).sendKeys("shailajaarige27@gmail.com");
			}
			//Thread.sleep(2000);
			public void password(WebDriver driver, String pwd)
			{
			driver.findElement(By.id("pass")).sendKeys("Admin@123");
			}
			//Thread.sleep(2000);
			public void Signin(WebDriver driver)
			{
			driver.findElement(By.id("send2")).click();
			}
			//Thread.sleep(2000);
			public void SignOut(WebDriver driver)
			{
			driver.findElement(By.xpath("//a[@aria-label='store logo']//img")).click();
			driver.close();
		}
public static void main(String[] args)  throws InterruptedException
{
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\shailaja\\OneDrive\\Documents\\Automation\\Browser extantion\\chromedriver.exe");
	WebDriver driver =new ChromeDriver();

	Luma_Login l= new  Luma_Login();

	l.url(driver);
	l.maximize(driver);
	l.cookies(driver);
	Thread.sleep(2000);
	l.signin(driver);
	Thread.sleep(2000);	
	String usn = null;
	l.email(driver, usn);
	Thread.sleep(2000);
	String pwd = null;
	l.password(driver, pwd);
	Thread.sleep(2000);
	l.Signin(driver);
	Thread.sleep(2000);
	l.SignOut(driver);
	
	
	driver.close();

	}
}


 

	



